
Approach:

Introduced layers for mainatining differents projects and services.(N-Tier architecture).

Serilog for Logging(currently i have used for different log levels but it still can be reduced as per our requirement.
example : captured logs only for Errors not for debug/Information).

Unit testing via MOQ . Currently i have captured unit test cases for few scenarios which can still be made better in terms of test cases.
It could have been still better if i would have used core/domain layer to have all common entities at one places. Example:  Models/Enums/Constants.
This Domain layer we can add as projects reference . this can help in avoiding circular dependency.

Important Note: Swagger is taking more time to load the data. Pereferably i would also go for Load testing using jmeter and  postman.
further optimization can be done as i could not complete due to time constraint.